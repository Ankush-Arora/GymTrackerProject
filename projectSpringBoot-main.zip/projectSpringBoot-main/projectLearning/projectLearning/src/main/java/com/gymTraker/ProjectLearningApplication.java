package com.gymTraker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectLearningApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectLearningApplication.class, args);
	}

}
