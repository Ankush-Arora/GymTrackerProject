package com.gymTraker.controller;

import java.util.List;
import java.util.Optional;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gymTraker.entity.AuthRequest;
import com.gymTraker.entity.AuthResponse;
import com.gymTraker.entity.GymMember;
import com.gymTraker.entity.User;
import com.gymTraker.service.CustomUserService;
import com.gymTraker.service.GymMemberService;
import com.gymTraker.util.JwtUtil;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class GymController {

	@Autowired
	private JwtUtil jwtUtil;

	@Autowired
	private CustomUserService userService;

	@Autowired
	private AuthenticationManager authenticationmanager;

	@Autowired
	private GymMemberService gymMemberService;

	@GetMapping("/searchMember")
	public ResponseEntity<?> searchLoanInformation(@RequestParam("searchMember")  int MemberNumber ) {
		GymMember present = null;
		present = gymMemberService.memberIsPresentOrNot(MemberNumber);
		if (present != null)
			return new ResponseEntity<GymMember>(present, new HttpHeaders(), HttpStatus.OK);
		return new ResponseEntity<String>("Member is not found ", new HttpHeaders(), HttpStatus.OK);
	}

	@GetMapping("/getAllMembers")
	public ResponseEntity<List<GymMember>> getAllMembers() {
		List<GymMember> list = gymMemberService.getAllMembersDetails();
		return new ResponseEntity<List<GymMember>>(list, new HttpHeaders(), HttpStatus.OK);
	}

	@PostConstruct
	public void addDetails() {
		userService.initUsers();
		gymMemberService.initNewLoan();
		System.out.println("Running properly");
	}

	@GetMapping("/getAllUsers")
	public ResponseEntity<List<User>> getAllUsers() {
		List<User> list = userService.getAllUsersDetails();
		return new ResponseEntity<List<User>>(list, new HttpHeaders(), HttpStatus.OK);
	}

	@PostMapping("/addNewUser")
	public ResponseEntity<User> addNewUser(@RequestBody User user) {
		userService.addNewUser(user);
		return new ResponseEntity<User>(user, new HttpHeaders(), HttpStatus.OK);
	}

	@PostMapping("addNewMember")
	public GymMember adddNewLoan(@RequestBody GymMember gymMember) {
		gymMemberService.addnewMemberDetails(gymMember);
		return gymMember;
	}
	
	@DeleteMapping("/delete/{id}")
	public String deleteStudent(@PathVariable("id") int id)
	{
		gymMemberService.deleteStudent(id);
		return "Record has been deleted";
	}


	@GetMapping("/{id}")
	public ResponseEntity<User> getEmployeeById(@PathVariable("id") Integer id) {
		User entity = userService.getEmployeeById(id);

		return new ResponseEntity<User>(entity, new HttpHeaders(), HttpStatus.OK);
	}
	
	@PostMapping("/update")
	public GymMember updateNewLoan(@RequestBody GymMember newMember)
	{
		return  gymMemberService.updateStudent(newMember);
		
	}
}
