package com.gymTraker.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import com.gymTraker.entity.GymMember;
import com.gymTraker.repository.GymMemberRepository;

@Service
public class GymMemberService {

	@Autowired
	private GymMemberRepository gymMemberRepository;

	public void initNewLoan() {
		GymMember loan1 = new GymMember();
		loan1.setMemberNumber(0001);
		loan1.setFirstName("Ankush (OWNER)");
		loan1.setLastName("Arora");
		loan1.setAddress("ankusharora22@gmail.com");
		loan1.setFees(1500);
		loan1.setFeesPaid("December/2022");
		
		gymMemberRepository.save(loan1);

		GymMember loan2 = new GymMember();
		loan2.setMemberNumber(456);
		loan2.setFirstName("Anand");
		loan2.setLastName("Negi");
		loan2.setAddress("anand90@gmail.com");
		loan2.setFees(1500);
		loan2.setFeesPaid("Sept/2022");
		gymMemberRepository.save(loan2);
		
		GymMember loan3 = new GymMember();
		loan3.setMemberNumber(897);
		loan3.setFirstName("Madan");
		loan3.setLastName("Pant");
		loan3.setAddress("madan120@gmail.com");
		loan3.setFees(1500);
		loan3.setFeesPaid("Jan/2023");
		gymMemberRepository.save(loan3);
		
		GymMember loan4 = new GymMember();
		loan4.setMemberNumber(871);
		loan4.setFirstName("Girish");
		loan4.setLastName("Bamrana");
		loan4.setAddress("girish69@gmail.com");
		loan4.setFees(1500);
		loan4.setFeesPaid("Mar/2023");
		gymMemberRepository.save(loan4);
		
		GymMember loan5 = new GymMember();
		loan5.setMemberNumber(706);
		loan5.setFirstName("Deepa");
		loan5.setLastName("Negi");
		loan5.setAddress("deepa@gmail.com");
		loan5.setFees(1500);
		loan5.setFeesPaid("Dec/2023");
		gymMemberRepository.save(loan5);
		
		GymMember loan6 = new GymMember();
		loan6.setMemberNumber(812);
		loan6.setFirstName("Kanchan");
		loan6.setLastName("Pant");
		loan6.setAddress("kanchan45@gmail.com");
		loan6.setFees(1500);
		loan6.setFeesPaid("Feb/2023");
		gymMemberRepository.save(loan6);
	}

	public List<GymMember> getAllMembersDetails() {
		List<GymMember> userList = gymMemberRepository.findAll();

		if (userList.size() > 0) {
			return userList;
		} else {
			return new ArrayList<GymMember>();
		}
	}
	
	public void deleteStudent(int loanNumber)
	{
		gymMemberRepository.deleteById(loanNumber);
	}
	
	public GymMember memberIsPresentOrNot(int memberNumber) {
		List<GymMember> userList = gymMemberRepository.findAll();
		for (GymMember each : userList) {
			if (  each.getMemberNumber() == memberNumber) {
				return each;
			}
		}
		return null;
	}
	
	public GymMember updateStudent(GymMember newMember)
	{
		Integer loanId=newMember.getMemberNumber();
		GymMember std=gymMemberRepository.findById(loanId).get();
		std.setFirstName(newMember.getFirstName());
		std.setLastName(newMember.getLastName());
		std.setAddress(newMember.getAddress());
		std.setFees(newMember.getFees());
		std.setFeesPaid(newMember.getFeesPaid());
		return gymMemberRepository.save(std);
	}

	public GymMember addnewMemberDetails(GymMember newMember) {
		gymMemberRepository.save(newMember);
		return newMember;
	}

}
