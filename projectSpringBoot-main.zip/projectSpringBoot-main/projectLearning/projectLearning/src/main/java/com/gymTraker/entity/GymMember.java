package com.gymTraker.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="MEMBERDETAIL")
public class GymMember{

	@Id
	private int memberNumber;
	private String firstName;
	private String lastName;
	private String address;
	private int fees;
	private String  feesPaid;
}
