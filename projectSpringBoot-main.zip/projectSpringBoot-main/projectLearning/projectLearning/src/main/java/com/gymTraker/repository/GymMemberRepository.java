package com.gymTraker.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gymTraker.entity.GymMember;

public interface GymMemberRepository extends JpaRepository<GymMember, Integer>{

}
